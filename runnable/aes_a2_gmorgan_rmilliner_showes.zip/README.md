# 🔱 AES Java 🔱
#### 128 bit AES Encryption and Encoding using Base64
---
### This project contains the following:

1. 2 Java Files containing the assignment code. 
2. Example output of the code. 
3. A runnable JAR file. 


In order to run the jar file, simply navigate to the file via the terminal or command line and type:

```
java -jar aes_example.jar
```

#### Let us know if you have any issues with the submission files. 

-Graeme, Reece, and Scott
